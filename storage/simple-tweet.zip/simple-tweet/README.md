# Simple Tweet

A simple microblogging site using django.

![screenshot](http://i.imgur.com/GgovJ3I.png)